import React from "react";
import "./TEXT13.sass";

function TEXT13(props) {
  const { x2012ShgIsBorn, text498, className } = props;

  return (
    <div className={`text1 ${className || ""}`}>
      <div className="x2012-shg-is-born roboto-medium-blueberry-40px">{x2012ShgIsBorn}</div>
      <div className="text-4 roboto-normal-storm-dust-24px">{text498}</div>
    </div>
  );
}

export default TEXT13;
