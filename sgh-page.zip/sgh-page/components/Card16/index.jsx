import React from "react";
import "./Card16.sass";

function Card16(props) {
  const { pexelsAndreaPiacquadio839586, className } = props;

  return (
    <div className={`card1-4 ${className || ""}`}>
      <img className="pexels-andrea-p-acquadio" src={pexelsAndreaPiacquadio839586} />
      <div className="text-2-1 roboto-normal-storm-dust-22px-2">
        “SHG has made such an impact over the years at my school. It has redefined the way we represent information
        during lessons and increased engagement.”
      </div>
      <div className="name-2 roboto-normal-storm-dust-22px">
        <span className="span-1 roboto-normal-azure-radiance-22px"></span>
        <span className="span-1 roboto-normal-storm-dust-24px"></span>
        <span className="span-1 roboto-bold-storm-dust-20px">
          Martin Odima Jr.
          <br />
        </span>
        <span className="span-1 roboto-normal-storm-dust-18px">@MartinOdimaJr</span>
      </div>
    </div>
  );
}

export default Card16;
