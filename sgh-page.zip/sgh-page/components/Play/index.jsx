import React from "react";
import "./Play.sass";

function Play(props) {
  const { src } = props;

  return (
    <div className="play">
      <img className="polygon-1" src={src} />
    </div>
  );
}

export default Play;
