import React from "react";
import "./ButtonSmallPrimary.sass";

function ButtonSmallPrimary(props) {
  const { children } = props;

  return (
    <div className="button-small-primary">
      <div className="button-small-primary-1">
        <div className="sign-in">{children}</div>
      </div>
    </div>
  );
}

export default ButtonSmallPrimary;
