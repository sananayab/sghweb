import React from "react";
import Group92 from "../Group92";
import "./SignupBtn3.sass";

function SignupBtn3() {
  return (
    <div className="signup-btn-3 border-1px-white">
      <div className="enter-code roboto-normal-cararra-18px">Enter Code</div>
      <Group92 />
    </div>
  );
}

export default SignupBtn3;
