import React from "react";
import "./Group191.sass";

function Group191(props) {
  const { className } = props;

  return (
    <div className={`group-191-1 ${className || ""}`}>
      <img
        className="pexels-andrea-p-acquadio-733872-1"
        src="https://anima-uploads.s3.amazonaws.com/projects/61346f5f10eb46a59c487961/releases/613940f00fa209db6bc1a9c3/img/pexels-andrea-piacquadio-733872-2@1x.png"
      />
      <div className="name-3 roboto-normal-storm-dust-22px">
        <span className="span-2 roboto-normal-azure-radiance-22px"></span>
        <span className="span-2 roboto-normal-storm-dust-24px"></span>
        <span className="span-2 roboto-bold-storm-dust-24px">
          Martin Odima Jr.
          <br />
        </span>
        <span className="span-2 roboto-normal-storm-dust-20px">@MartinOdimaJr</span>
      </div>
    </div>
  );
}

export default Group191;
