import React from "react";
import "./Group190.sass";

function Group190(props) {
  const { children } = props;

  return (
    <div className="group-190">
      <h1 className="always-seek-knowledg">{children}</h1>
    </div>
  );
}

export default Group190;
