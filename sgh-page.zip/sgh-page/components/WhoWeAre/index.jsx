import React from "react";
import { Link } from "react-router-dom";
import HEADER2 from "../HEADER2";
import X1 from "../X1";
import Group190 from "../Group190";
import TEXT13 from "../TEXT13";
import Card16 from "../Card16";
import Group195 from "../Group195";
import Lap2 from "../Lap2";
import Group191 from "../Group191";
import ClientLogo22 from "../ClientLogo22";
import Technology2 from "../Technology2";
import Group1142 from "../Group1142";
import Group116 from "../Group116";
import "./WhoWeAre.sass";

function WhoWeAre(props) {
  const {
    hero,
    rectangle5,
    rectangle6,
    group134,
    overlapGroup3,
    x6,
    text1,
    text7,
    path87,
    path31105,
    group3231,
    group3232,
    path31120,
    path31121,
    path31122,
    path31123,
    group3233,
    path31125,
    path31126,
    path31127,
    path31128,
    group3234,
    group3235,
    path31151,
    path31152,
    path31153,
    path31155,
    path31156,
    path31157,
    path31158,
    path31159,
    path31154,
    group3237,
    path31171,
    c,
    path31173,
    path31174,
    path31175,
    path31176,
    path31177,
    path31178,
    path31179,
    path31180,
    path31181,
    path31182,
    path31183,
    path31184,
    path31185,
    path31186,
    path31187,
    path31188,
    path31189,
    path31190,
    group3238,
    group3239,
    path31193,
    path31194,
    group3240,
    path31196,
    path31197,
    group3242,
    path31199,
    path31200,
    path31201,
    path31202,
    path31203,
    path31204,
    path31205,
    path31206,
    path31207,
    path31208,
    path31209,
    path31210,
    path31211,
    group3245,
    group3246,
    path31214,
    path31215,
    group3247,
    path31217,
    path31218,
    path31219,
    path31220,
    path31221,
    path31222,
    path31223,
    group3251,
    path31225,
    group3252,
    path31227,
    path31228,
    group3253,
    path31230,
    path31231,
    c2,
    path31233,
    path31234,
    path31235,
    group3260,
    path31237,
    path31238,
    path31239,
    path31240,
    path31241,
    path31242,
    path31243,
    path31244,
    path31245,
    path31246,
    path31247,
    path31248,
    group3261,
    group3262,
    path31251,
    path31252,
    group3263,
    path31254,
    path31255,
    rectangle1182,
    path31256,
    group3268,
    path31258,
    path31259,
    path31260,
    path31261,
    path31262,
    path31263,
    path31264,
    path31265,
    path31266,
    path31267,
    group3272,
    path31269,
    path31270,
    group3273,
    path31272,
    path31273,
    path31274,
    group3274,
    group3275,
    path31277,
    path31278,
    group3281,
    path31280,
    path31281,
    path31282,
    path31283,
    c3,
    path31284,
    rectangle1183,
    path31285,
    group3287,
    v2,
    path31287,
    path31288,
    path31289,
    path31290,
    group3290,
    group3291,
    path31293,
    path31294,
    group3292,
    group3294,
    group3293,
    path31298,
    path31299,
    path31300,
    path31301,
    v,
    c4,
    path31303,
    path31304,
    path31305,
    path31306,
    path31307,
    path31308,
    group3301,
    group3304,
    path31311,
    path31312,
    path31313,
    group3305,
    group3306,
    path31316,
    path31317,
    group3307,
    path31319,
    path31320,
    path31321,
    path31322,
    path31323,
    path31324,
    group3314,
    group3316,
    path31327,
    path31328,
    group3322,
    path31330,
    path31331,
    group3326,
    path31333,
    path31334,
    path31340,
    path31337,
    path31335,
    path31338,
    path31336,
    path31339,
    path31341,
    path31342,
    path31343,
    path31344,
    path31345,
    text5,
    text6,
    path88,
    path31657,
    path31658,
    path31659,
    path31660,
    path31661,
    path31662,
    path31663,
    path31664,
    path31665,
    path31666,
    path31667,
    path31668,
    path31669,
    path31670,
    path31671,
    path31672,
    path31673,
    path31674,
    path31675,
    path31676,
    path31677,
    path31678,
    path31679,
    path31680,
    path31681,
    path31682,
    path31683,
    path31684,
    path31685,
    path31686,
    path31687,
    path31688,
    path31689,
    path31690,
    path31691,
    path31692,
    path31693,
    path31694,
    path31695,
    path31696,
    path31697,
    path31698,
    group3456,
    group3457,
    rectangle1368,
    path31718,
    path31719,
    path31720,
    path31721,
    path31722,
    path31723,
    path31725,
    path31724,
    path31726,
    group3470,
    path31728,
    path31729,
    path31730,
    path31731,
    path31732,
    path31733,
    path31734,
    path31735,
    path31736,
    path31737,
    path31738,
    path31739,
    path31740,
    path31741,
    path31742,
    path31743,
    path31744,
    path31745,
    path31746,
    group3483,
    overlapGroup,
    path31749,
    path31750,
    rectangle1393,
    rectangle1399,
    path31751,
    path31752,
    path31754,
    path31755,
    path31756,
    path31753,
    group3488,
    overlapGroup1,
    path31759,
    path31760,
    path31761,
    path31762,
    path31763,
    path31764,
    path31765,
    path31766,
    path31767,
    path31768,
    path31769,
    path31770,
    path31771,
    path31772,
    path31773,
    path31774,
    path31775,
    path31776,
    path31777,
    path31778,
    path31779,
    path31780,
    path31781,
    path31782,
    path31783,
    path31784,
    group3496,
    group3495,
    path31787,
    path31788,
    path31790,
    path31793,
    path31792,
    path31794,
    path31789,
    path31791,
    x62,
    text8,
    text9,
    ic_Place_24Px,
    daniaBeachFl,
    ic_Place_24Px2,
    daniaBeachFl2,
    text10,
    spanText,
    spanText2,
    spanText3,
    spanText4,
    pexelsMatheusBertelli3856027,
    pexelsHelenaLopes1015568,
    pexelsFauxels3184418,
    pexelsAlexanderSuhorucov6457562,
    pexelsAlexanderSuhorucov64575622,
    pexelsHelenaLopes10155682,
    text19,
    text29,
    text30,
    text31,
    overlapGroup15,
    group6,
    group83,
    text14,
    text15,
    x63,
    text11,
    text12,
    pexelsMatheusBertelli38560272,
    pexelsHelenaLopes10155683,
    pexelsFauxels31844182,
    pexelsAlexanderSuhorucov64575623,
    pexelsAlexanderSuhorucov64575624,
    pexelsHelenaLopes10155684,
    text13,
    text16,
    text17,
    pexelsAndreaPiacquadio733872,
    spanText5,
    spanText6,
    spanText7,
    spanText8,
    ourInvestors,
    text18,
    bg,
    background,
    creative,
    animation,
    drawing,
    graphicDesign,
    illustration,
    photography,
    business,
    entrepreneurship,
    freelanceEntrepre,
    leadership,
    marketing,
    productivity,
    more,
    technology,
    dataScience,
    gameDesign,
    mobileDevelopment,
    productManagement,
    webDevelopment,
    more2,
    productManagement2,
    webDevelopment2,
    more3,
    path90,
    hEADER2Props,
    x1Props,
    group190Props,
    tEXT13Props,
    tEXT132Props,
    card16Props,
    card162Props,
    card163Props,
    card164Props,
    card165Props,
    card166Props,
    card167Props,
    card168Props,
    card169Props,
    lap2Props,
    group191Props,
    group1912Props,
    group1913Props,
    group195Props,
    clientLogo22Props,
    technology2Props,
    group1142Props,
    group116Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="who-we-are screen">
        <div className="overlap-group18">
          <div className="overlap-group2">
            <div className="hero" style={{ backgroundImage: `url(${hero})` }}></div>
            <HEADER2 hEADER5Props={hEADER2Props.hEADER5Props} />
            <img className="rectangle-5" src={rectangle5} />
            <img className="rectangle-6" src={rectangle6} />
            <X1
              menu2Props={x1Props.menu2Props}
              signupBtn2Props={x1Props.signupBtn2Props}
              signupBtn22Props={x1Props.signupBtn22Props}
              signupBtn23Props={x1Props.signupBtn23Props}
            />
          </div>
          <div className="group-134" style={{ backgroundImage: `url(${group134})` }}>
            <div className="overlap-group3" style={{ backgroundImage: `url(${overlapGroup3})` }}>
              <Group190>{group190Props.children}</Group190>
            </div>
          </div>
          <div className="x6" style={{ backgroundImage: `url(${x6})` }}>
            <div className="text roboto-medium-blueberry-40px">{text1}</div>
            <div className="text-1 roboto-normal-storm-dust-24px">{text7}</div>
            <TEXT13 x2012ShgIsBorn={tEXT13Props.x2012ShgIsBorn} text498={tEXT13Props.text498} />
            <div className="overlap-group13">
              <TEXT13
                x2012ShgIsBorn={tEXT132Props.x2012ShgIsBorn}
                text498={tEXT132Props.text498}
                className={tEXT132Props.className}
              />
              <div className="overlap-group11">
                <img className="path-87" src={path87} />
                <div className="overlap-group9">
                  <img className="path-31105" src={path31105} />
                  <img className="group-3231" src={group3231} />
                  <div className="group-3232" style={{ backgroundImage: `url(${group3232})` }}>
                    <div className="overlap-group">
                      <img className="path-31120" src={path31120} />
                      <img className="path-31121" src={path31121} />
                      <img className="path-3112" src={path31122} />
                      <img className="path-31123" src={path31123} />
                    </div>
                  </div>
                  <div className="group-3233" style={{ backgroundImage: `url(${group3233})` }}>
                    <div className="overlap-group">
                      <img className="path-31125" src={path31125} />
                      <img className="path-31126" src={path31126} />
                      <img className="path-3112" src={path31127} />
                      <img className="path-31128" src={path31128} />
                    </div>
                  </div>
                  <img className="group-3234" src={group3234} />
                  <img className="group-3235" src={group3235} />
                  <div className="group-3236">
                    <div className="overlap-group2-1">
                      <img className="path-31151" src={path31151} />
                      <img className="path-31152" src={path31152} />
                      <img className="path-31153" src={path31153} />
                      <img className="path-31155" src={path31155} />
                      <img className="path-31156" src={path31156} />
                      <img className="path-31157" src={path31157} />
                      <img className="path-31158" src={path31158} />
                      <img className="path-31159" src={path31159} />
                    </div>
                    <img className="path-31154" src={path31154} />
                  </div>
                  <img className="group-3237" src={group3237} />
                  <img className="path-31171" src={path31171} />
                  <div className="overlap-group3-1">
                    <div className="c" style={{ backgroundImage: `url(${c})` }}></div>
                    <img className="path-31173" src={path31173} />
                    <img className="path-31174" src={path31174} />
                    <img className="path-31175" src={path31175} />
                    <img className="path-31176" src={path31176} />
                    <img className="path-31177" src={path31177} />
                    <img className="path-31178" src={path31178} />
                    <img className="path-31179" src={path31179} />
                    <img className="path-31180" src={path31180} />
                    <img className="path-31181" src={path31181} />
                    <img className="path-31182" src={path31182} />
                    <img className="path-31183" src={path31183} />
                    <img className="path-31184" src={path31184} />
                    <img className="path-31185" src={path31185} />
                    <img className="path-31186" src={path31186} />
                    <div className="overlap-group-1">
                      <img className="path-31187" src={path31187} />
                      <img className="path-31188" src={path31188} />
                      <img className="path-31189" src={path31189} />
                      <img className="path-31190" src={path31190} />
                      <div className="group-3238" style={{ backgroundImage: `url(${group3238})` }}></div>
                      <div className="group-3239" style={{ backgroundImage: `url(${group3239})` }}></div>
                      <img className="path-31193" src={path31193} />
                      <img className="path-31194" src={path31194} />
                      <div className="group-3240" style={{ backgroundImage: `url(${group3240})` }}></div>
                      <img className="path-31196" src={path31196} />
                      <img className="path-31197" src={path31197} />
                    </div>
                    <div className="overlap-group1">
                      <div className="group-3242" style={{ backgroundImage: `url(${group3242})` }}>
                        <img className="path-31199" src={path31199} />
                      </div>
                      <img className="path-31200" src={path31200} />
                    </div>
                    <img className="path-31201" src={path31201} />
                    <img className="path-31202" src={path31202} />
                  </div>
                  <div className="overlap-group4">
                    <img className="path-31203" src={path31203} />
                    <img className="path-31204" src={path31204} />
                    <img className="path-31205" src={path31205} />
                    <img className="path-31206" src={path31206} />
                    <img className="path-31207" src={path31207} />
                    <div className="group-3250">
                      <div className="group-3249">
                        <div className="group-3248">
                          <div className="overlap-group-2">
                            <img className="path-31208" src={path31208} />
                            <img className="path-31209" src={path31209} />
                            <img className="path-31210" src={path31210} />
                            <img className="path-31211" src={path31211} />
                            <div className="group-3245" style={{ backgroundImage: `url(${group3245})` }}></div>
                            <div className="group-3246" style={{ backgroundImage: `url(${group3246})` }}></div>
                            <img className="path-31214" src={path31214} />
                            <img className="path-31215" src={path31215} />
                            <div className="group-3247" style={{ backgroundImage: `url(${group3247})` }}></div>
                            <img className="path-31217" src={path31217} />
                          </div>
                        </div>
                      </div>
                    </div>
                    <img className="path-31218" src={path31218} />
                    <img className="path-31219" src={path31219} />
                    <img className="path-31220" src={path31220} />
                    <img className="path-31221" src={path31221} />
                    <img className="path-31222" src={path31222} />
                    <img className="path-31223" src={path31223} />
                    <div className="group-3251" style={{ backgroundImage: `url(${group3251})` }}>
                      <img className="path-31225" src={path31225} />
                    </div>
                    <div className="group-3252" style={{ backgroundImage: `url(${group3252})` }}>
                      <img className="path-31227" src={path31227} />
                    </div>
                    <img className="path-31228" src={path31228} />
                    <div className="overlap-group1-1">
                      <div className="group-3253" style={{ backgroundImage: `url(${group3253})` }}>
                        <img className="path-31230" src={path31230} />
                      </div>
                      <img className="path-31231" src={path31231} />
                    </div>
                    <div className="c-1" style={{ backgroundImage: `url(${c2})` }}></div>
                    <img className="path-31233" src={path31233} />
                    <img className="path-31234" src={path31234} />
                    <img className="path-31235" src={path31235} />
                  </div>
                  <div className="group-3260" style={{ backgroundImage: `url(${group3260})` }}></div>
                  <div className="overlap-group5">
                    <img className="path-31237" src={path31237} />
                    <img className="path-31238" src={path31238} />
                    <img className="path-31239" src={path31239} />
                    <img className="path-31240" src={path31240} />
                    <img className="path-31241" src={path31241} />
                    <div className="ellipse-211"></div>
                    <img className="path-31242" src={path31242} />
                    <img className="path-31243" src={path31243} />
                    <img className="path-31244" src={path31244} />
                    <img className="path-31245" src={path31245} />
                    <img className="path-31246" src={path31246} />
                    <img className="path-31247" src={path31247} />
                    <img className="path-31248" src={path31248} />
                    <div className="group-3261" style={{ backgroundImage: `url(${group3261})` }}></div>
                    <div className="group-3262" style={{ backgroundImage: `url(${group3262})` }}></div>
                    <img className="path-31251" src={path31251} />
                    <img className="path-31252" src={path31252} />
                    <div className="group-3263" style={{ backgroundImage: `url(${group3263})` }}></div>
                    <img className="path-31254" src={path31254} />
                    <div className="overlap-group-3">
                      <img className="path-31255" src={path31255} />
                      <img className="rectangle-1182" src={rectangle1182} />
                    </div>
                    <div className="overlap-group1-2">
                      <img className="path-31256" src={path31256} />
                      <div className="group-3268" style={{ backgroundImage: `url(${group3268})` }}></div>
                    </div>
                  </div>
                  <div className="overlap-group6">
                    <div className="overlap-group-4">
                      <img className="path-31258" src={path31258} />
                      <img className="path-31259" src={path31259} />
                      <img className="path-31260" src={path31260} />
                      <img className="path-31261" src={path31261} />
                    </div>
                    <img className="path-31262" src={path31262} />
                    <img className="path-31263" src={path31263} />
                    <img className="path-31264" src={path31264} />
                    <img className="path-31265" src={path31265} />
                    <img className="path-31266" src={path31266} />
                    <img className="path-31267" src={path31267} />
                    <div className="group-3272" style={{ backgroundImage: `url(${group3272})` }}></div>
                    <img className="path-31269" src={path31269} />
                    <img className="path-31270" src={path31270} />
                    <div className="group-3273" style={{ backgroundImage: `url(${group3273})` }}></div>
                    <img className="path-31272" src={path31272} />
                    <img className="path-31273" src={path31273} />
                    <img className="path-31274" src={path31274} />
                    <div className="group-3274" style={{ backgroundImage: `url(${group3274})` }}></div>
                    <div className="overlap-group1-3">
                      <div className="group-3275" style={{ backgroundImage: `url(${group3275})` }}>
                        <img className="path-31277" src={path31277} />
                      </div>
                      <img className="path-31278" src={path31278} />
                    </div>
                    <div className="overlap-group2-2">
                      <div className="group-3281" style={{ backgroundImage: `url(${group3281})` }}></div>
                      <img className="path-31280" src={path31280} />
                      <img className="path-31281" src={path31281} />
                    </div>
                    <img className="path-31282" src={path31282} />
                    <img className="path-31283" src={path31283} />
                    <img className="c-2" src={c3} />
                    <div className="overlap-group3-2">
                      <img className="path-31284" src={path31284} />
                      <img className="rectangle-1183" src={rectangle1183} />
                    </div>
                    <div className="overlap-group4-1">
                      <img className="path-31285" src={path31285} />
                      <div className="group-3287" style={{ backgroundImage: `url(${group3287})` }}></div>
                    </div>
                  </div>
                  <div className="overlap-group7">
                    <div className="overlap-group2-3">
                      <div className="overlap-group1-4">
                        <img className="v-2" src={v2} />
                        <div className="group-3296">
                          <div className="group-3295">
                            <div className="overlap-group-5">
                              <img className="path-31287" src={path31287} />
                              <img className="path-31288" src={path31288} />
                              <img className="path-31289" src={path31289} />
                              <img className="path-31290" src={path31290} />
                              <div className="group-3290" style={{ backgroundImage: `url(${group3290})` }}></div>
                              <div className="group-3291" style={{ backgroundImage: `url(${group3291})` }}></div>
                              <img className="path-31293" src={path31293} />
                              <img className="path-31294" src={path31294} />
                              <div className="group-3292" style={{ backgroundImage: `url(${group3292})` }}></div>
                              <div className="group-3294" style={{ backgroundImage: `url(${group3294})` }}>
                                <div className="group-3293" style={{ backgroundImage: `url(${group3293})` }}></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <img className="path-31298" src={path31298} />
                      <img className="path-31299" src={path31299} />
                      <img className="path-31300" src={path31300} />
                      <img className="path-31301" src={path31301} />
                      <div className="v" style={{ backgroundImage: `url(${v})` }}></div>
                      <div className="c-3" style={{ backgroundImage: `url(${c4})` }}></div>
                      <img className="path-31303" src={path31303} />
                      <img className="path-31304" src={path31304} />
                      <img className="path-31305" src={path31305} />
                    </div>
                    <div className="overlap-group4-2">
                      <div className="overlap-group-6">
                        <img className="path-31306" src={path31306} />
                        <img className="path-31307" src={path31307} />
                      </div>
                      <img className="path-31308" src={path31308} />
                      <div className="group-3301" style={{ backgroundImage: `url(${group3301})` }}></div>
                      <div className="group-3304" style={{ backgroundImage: `url(${group3304})` }}></div>
                      <div className="overlap-group1-5">
                        <img className="path-31311" src={path31311} />
                        <img className="path-31312" src={path31312} />
                        <img className="path-31313" src={path31313} />
                        <div className="group-3305" style={{ backgroundImage: `url(${group3305})` }}></div>
                        <div className="group-3306" style={{ backgroundImage: `url(${group3306})` }}></div>
                        <img className="path-31316" src={path31316} />
                        <img className="path-31317" src={path31317} />
                        <div className="group-3307" style={{ backgroundImage: `url(${group3307})` }}></div>
                        <img className="path-31319" src={path31319} />
                      </div>
                      <img className="path-31320" src={path31320} />
                      <div className="overlap-group2-4">
                        <img className="path-31321" src={path31321} />
                        <img className="path-3132" src={path31322} />
                      </div>
                      <div className="overlap-group3-3">
                        <img className="path-31323" src={path31323} />
                        <img className="path-3132" src={path31324} />
                      </div>
                      <div className="group-3314" style={{ backgroundImage: `url(${group3314})` }}></div>
                    </div>
                    <div className="overlap-group5-1">
                      <div className="group-3316" style={{ backgroundImage: `url(${group3316})` }}>
                        <img className="path-31327" src={path31327} />
                      </div>
                      <img className="path-31328" src={path31328} />
                    </div>
                    <div className="overlap-group6-1">
                      <div className="group-3322" style={{ backgroundImage: `url(${group3322})` }}></div>
                      <div className="overlap-group-7">
                        <img className="path-31330" src={path31330} />
                        <img className="path-31331" src={path31331} />
                      </div>
                    </div>
                  </div>
                  <div className="overlap-group8">
                    <div className="group-3326" style={{ backgroundImage: `url(${group3326})` }}>
                      <img className="path-31333" src={path31333} />
                    </div>
                    <img className="path-31334" src={path31334} />
                  </div>
                  <div className="group-3328">
                    <img className="path-31340" src={path31340} />
                    <img className="path-31337" src={path31337} />
                    <img className="path-31335" src={path31335} />
                    <img className="path-31338" src={path31338} />
                    <img className="path-31336" src={path31336} />
                    <img className="path-31339" src={path31339} />
                  </div>
                  <img className="path-31341" src={path31341} />
                  <img className="path-31342" src={path31342} />
                  <img className="path-31343" src={path31343} />
                  <img className="path-31344" src={path31344} />
                  <img className="path-31345" src={path31345} />
                </div>
              </div>
            </div>
            <div className="overlap-group14">
              <div className="overlap-group-8">
                <div className="text-5 roboto-medium-blueberry-40px">{text5}</div>
                <div className="text-6 roboto-normal-storm-dust-24px">{text6}</div>
              </div>
              <div className="overlap-group12">
                <img className="path-88" src={path88} />
                <div className="overlap-group10">
                  <div className="overlap-group-9">
                    <img className="path-31657" src={path31657} />
                    <img className="path-31658" src={path31658} />
                  </div>
                  <div className="overlap-group6-2">
                    <div className="overlap-group-10">
                      <img className="path-31659" src={path31659} />
                      <img className="path-31660" src={path31660} />
                      <img className="path-31661" src={path31661} />
                      <img className="path-31662" src={path31662} />
                      <img className="path-31663" src={path31663} />
                    </div>
                    <img className="path-31664" src={path31664} />
                    <div className="overlap-group1-6">
                      <img className="path-31665" src={path31665} />
                      <img className="path-31666" src={path31666} />
                      <div className="rectangle-1358"></div>
                      <div className="rectangle-1359"></div>
                      <div className="rectangle-1360"></div>
                    </div>
                    <img className="path-31667" src={path31667} />
                    <div className="overlap-group2-5">
                      <img className="path-31668" src={path31668} />
                      <img className="path-31669" src={path31669} />
                      <img className="path-31670" src={path31670} />
                      <img className="path-31671" src={path31671} />
                      <img className="path-31672" src={path31672} />
                    </div>
                    <img className="path-31673" src={path31673} />
                    <img className="path-31674" src={path31674} />
                    <img className="path-31675" src={path31675} />
                    <img className="path-31676" src={path31676} />
                    <img className="path-31677" src={path31677} />
                    <div className="overlap-group3-4">
                      <img className="path-31678" src={path31678} />
                      <img className="path-31679" src={path31679} />
                      <div className="rectangle-1361"></div>
                      <div className="rectangle-1362"></div>
                      <div className="rectangle-1363"></div>
                    </div>
                    <img className="path-31680" src={path31680} />
                    <img className="path-31681" src={path31681} />
                    <img className="path-31682" src={path31682} />
                    <div className="overlap-group4-3">
                      <img className="path-31683" src={path31683} />
                      <img className="path-31684" src={path31684} />
                    </div>
                    <img className="path-31685" src={path31685} />
                    <img className="path-31686" src={path31686} />
                    <img className="path-31687" src={path31687} />
                    <img className="path-31688" src={path31688} />
                    <img className="path-31689" src={path31689} />
                    <div className="group-3454">
                      <img className="path-31690" src={path31690} />
                      <div className="overlap-group5-2">
                        <img className="path-31691" src={path31691} />
                        <img className="path-31692" src={path31692} />
                      </div>
                    </div>
                    <img className="path-31693" src={path31693} />
                    <img className="path-31694" src={path31694} />
                    <img className="path-31695" src={path31695} />
                    <img className="path-31696" src={path31696} />
                    <img className="path-31697" src={path31697} />
                    <img className="path-31698" src={path31698} />
                    <div className="ellipse-214"></div>
                  </div>
                  <img className="group-3456" src={group3456} />
                  <div className="rectangle-1364"></div>
                  <div className="overlap-group7-1">
                    <div className="group-3457" style={{ backgroundImage: `url(${group3457})` }}>
                      <div className="rectangle-1365"></div>
                    </div>
                    <div className="overlap-group1-7">
                      <div className="rectangle-1366"></div>
                      <div className="rectangle-1367"></div>
                      <img className="rectangle-1368" src={rectangle1368} />
                      <div className="rectangle-1369"></div>
                      <div className="rectangle-1370"></div>
                      <div className="group-3458">
                        <div className="rectangle-1371"></div>
                        <div className="rectangle-1372"></div>
                        <div className="overlap-group-11">
                          <div className="rectangle-1373"></div>
                          <div className="rectangle-1374"></div>
                          <div className="rectangle-1375"></div>
                          <div className="rectangle-1376"></div>
                          <div className="rectangle-1377"></div>
                          <img className="path-31718" src={path31718} />
                        </div>
                      </div>
                      <div className="group-3459">
                        <div className="rectangle-1378"></div>
                        <div className="rectangle-1379"></div>
                        <div className="rectangle-1380"></div>
                        <div className="rectangle-1381"></div>
                        <div className="rectangle-1382"></div>
                        <div className="rectangle-1383"></div>
                      </div>
                    </div>
                    <div className="overlap-group2-6">
                      <div className="overlap-group-12">
                        <div className="rectangle-1384"></div>
                        <img className="path-31719" src={path31719} />
                      </div>
                      <div className="rectangle-1385"></div>
                      <div className="overlap-group1-8">
                        <div className="rectangle-1386"></div>
                        <img className="path-31720" src={path31720} />
                      </div>
                    </div>
                    <div className="overlap-group3-5">
                      <div className="rectangle-1387"></div>
                      <img className="path-31721" src={path31721} />
                    </div>
                    <div className="group-3465">
                      <div className="overlap-group4-4">
                        <div className="rectangle-1388"></div>
                        <div className="rectangle-1389"></div>
                        <div className="rectangle-1390"></div>
                        <img className="path-31722" src={path31722} />
                        <img className="path-31723" src={path31723} />
                        <img className="path-31725" src={path31725} />
                      </div>
                      <img className="path-31724" src={path31724} />
                    </div>
                    <div className="overlap-group5-3">
                      <div className="overlap-group-13">
                        <div className="rectangle-1391"></div>
                        <img className="path-31726" src={path31726} />
                      </div>
                      <div className="ellipse-215"></div>
                      <div className="rectangle-1392"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="overlap-group16">
            <div className="group-3470" style={{ backgroundImage: `url(${group3470})` }}></div>
            <div className="overlap-group3-6">
              <div className="overlap-group-14">
                <img className="path-31728" src={path31728} />
                <img className="path-31729" src={path31729} />
              </div>
              <img className="path-31730" src={path31730} />
              <div className="overlap-group1-9">
                <img className="path-31731" src={path31731} />
                <img className="path-31732" src={path31732} />
                <img className="path-31733" src={path31733} />
              </div>
              <div className="overlap-group2-7">
                <img className="path-31734" src={path31734} />
                <img className="path-31735" src={path31735} />
                <img className="path-31736" src={path31736} />
              </div>
            </div>
            <div className="overlap-group4-5">
              <div className="overlap-group-15">
                <img className="path-31737" src={path31737} />
                <img className="path-31738" src={path31738} />
                <img className="path-31739" src={path31739} />
              </div>
              <div className="overlap-group1-10">
                <img className="path-31740" src={path31740} />
                <img className="path-31741" src={path31741} />
                <div className="group-3476">
                  <img className="path-3174" src={path31742} />
                  <div className="overlap-group-16">
                    <img className="path-31743" src={path31743} />
                    <img className="path-31744" src={path31744} />
                    <img className="path-31745" src={path31745} />
                  </div>
                </div>
                <img className="path-31746" src={path31746} />
              </div>
            </div>
            <div className="overlap-group5-4">
              <div className="group-3483" style={{ backgroundImage: `url(${group3483})` }}>
                <div className="overlap-group-17" style={{ backgroundImage: `url(${overlapGroup})` }}>
                  <img className="path-3174" src={path31749} />
                  <img className="path-31750" src={path31750} />
                </div>
                <div className="group-3482">
                  <div className="flex-col">
                    <div className="group-3479">
                      <div className="ellipse-216"></div>
                      <img className="rectangle-1393" src={rectangle1393} />
                    </div>
                    <div className="group-3480">
                      <div className="rectangle-1394"></div>
                      <div className="rectangle-1395"></div>
                      <div className="rectangle-1396"></div>
                    </div>
                  </div>
                  <div className="flex-col-1">
                    <img className="rectangle-1399" src={rectangle1399} />
                    <div className="group-3481">
                      <div className="rectangle-1397"></div>
                      <div className="rectangle-1398"></div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="overlap-group1-11">
                <img className="path-31751" src={path31751} />
                <img className="path-31752" src={path31752} />
                <div className="group-3484">
                  <div className="overlap-group-18">
                    <img className="path-31754" src={path31754} />
                    <img className="path-31755" src={path31755} />
                    <img className="path-31756" src={path31756} />
                  </div>
                  <img className="path-31753" src={path31753} />
                </div>
              </div>
            </div>
            <div className="overlap-group6-3">
              <div className="group-3488" style={{ backgroundImage: `url(${group3488})` }}>
                <div className="overlap-group1-12" style={{ backgroundImage: `url(${overlapGroup1})` }}>
                  <img className="path-31759" src={path31759} />
                  <div className="group-3487">
                    <div className="rectangle-1400"></div>
                    <div className="rectangle-1401"></div>
                    <div className="overlap-group-19">
                      <div className="rectangle-1402"></div>
                      <div className="rectangle-1403"></div>
                    </div>
                    <div className="rectangle-1404"></div>
                    <div className="rectangle-1405"></div>
                  </div>
                </div>
              </div>
              <div className="overlap-group2-8">
                <img className="path-31760" src={path31760} />
                <img className="path-31761" src={path31761} />
                <img className="path-31762" src={path31762} />
              </div>
            </div>
            <div className="overlap-group7-2">
              <div className="overlap-group-20">
                <img className="path-31763" src={path31763} />
                <img className="path-31764" src={path31764} />
                <img className="path-31765" src={path31765} />
                <img className="path-31766" src={path31766} />
                <img className="path-31767" src={path31767} />
                <img className="path-31768" src={path31768} />
                <div className="ellipse-217"></div>
                <div className="ellipse-218"></div>
                <img className="path-31769" src={path31769} />
                <img className="path-31770" src={path31770} />
                <img className="path-31771" src={path31771} />
                <img className="path-31772" src={path31772} />
                <div className="ellipse-219"></div>
                <img className="path-31773" src={path31773} />
              </div>
              <div className="overlap-group1-13">
                <img className="path-31774" src={path31774} />
                <div className="rectangle-1406"></div>
                <img className="path-31775" src={path31775} />
                <div className="overlap-group-21">
                  <img className="path-31776" src={path31776} />
                  <img className="path-31777" src={path31777} />
                </div>
                <img className="path-31778" src={path31778} />
                <img className="path-31779" src={path31779} />
                <img className="path-31780" src={path31780} />
                <img className="path-31781" src={path31781} />
                <img className="path-31782" src={path31782} />
                <img className="path-31783" src={path31783} />
                <img className="path-31784" src={path31784} />
              </div>
            </div>
            <div className="group-3496" style={{ backgroundImage: `url(${group3496})` }}>
              <div className="group-3495" style={{ backgroundImage: `url(${group3495})` }}></div>
            </div>
            <div className="overlap-group8-1">
              <div className="rectangle-1407"></div>
              <img className="path-31787" src={path31787} />
              <img className="path-31788" src={path31788} />
            </div>
            <div className="group-3498">
              <div className="rectangle-1409"></div>
            </div>
            <div className="group-3499">
              <div className="flex-row-1">
                <img className="path-31790" src={path31790} />
                <img className="path-31793" src={path31793} />
              </div>
              <img className="path-31792" src={path31792} />
              <div className="flex-row-2">
                <div className="flex-col-2">
                  <img className="path-31794" src={path31794} />
                  <img className="path-31789" src={path31789} />
                </div>
                <img className="path-31791" src={path31791} />
              </div>
            </div>
          </div>
        </div>
        <div className="overlap-group20">
          <div className="x6-1" style={{ backgroundImage: `url(${x62})` }}>
            <div className="flex-col-3">
              <div className="text roboto-medium-blueberry-40px">{text8}</div>
              <div className="text-1 roboto-normal-storm-dust-24px">{text9}</div>
            </div>
            <div className="flex-row-3 roboto-normal-storm-dust-24px">
              <img className="icplace24px" src={ic_Place_24Px} />
              <div className="dania-beach-fl">{daniaBeachFl}</div>
              <img className="icplace24px-1" src={ic_Place_24Px2} />
              <div className="dania-beach-fl-1">{daniaBeachFl2}</div>
            </div>
            <div className="text-10 roboto-normal-azure-radiance-22px">{text10}</div>
            <div className="name roboto-normal-storm-dust-22px">
              <span className="roboto-normal-azure-radiance-22px">{spanText}</span>
              <span className="roboto-normal-storm-dust-24px">{spanText2}</span>
              <span className="roboto-bold-storm-dust-20px">{spanText3}</span>
              <span className="roboto-normal-storm-dust-18px">{spanText4}</span>
            </div>
            <div className="flex-row-4">
              <img className="pexels" src={pexelsMatheusBertelli3856027} />
              <img className="pexels-1" src={pexelsHelenaLopes1015568} />
            </div>
            <div className="flex-row">
              <img className="pexels" src={pexelsFauxels3184418} />
              <img className="pexels-1" src={pexelsAlexanderSuhorucov6457562} />
            </div>
            <div className="flex-row">
              <img className="pexels" src={pexelsAlexanderSuhorucov64575622} />
              <img className="pexels-1" src={pexelsHelenaLopes10155682} />
            </div>
          </div>
          <div className="x8">
            <div className="text-19 roboto-medium-blueberry-40px">{text19}</div>
            <div className="text-29 roboto-normal-storm-dust-24px">{text29}</div>
            <div className="scroll-group-1">
              <div className="overlap-group-22">
                <Card16 pexelsAndreaPiacquadio839586={card16Props.pexelsAndreaPiacquadio839586} />
                <div className="group-3505">
                  <Card16
                    pexelsAndreaPiacquadio839586={card162Props.pexelsAndreaPiacquadio839586}
                    className={card162Props.className}
                  />
                  <Card16
                    pexelsAndreaPiacquadio839586={card163Props.pexelsAndreaPiacquadio839586}
                    className={card163Props.className}
                  />
                  <Card16
                    pexelsAndreaPiacquadio839586={card164Props.pexelsAndreaPiacquadio839586}
                    className={card164Props.className}
                  />
                  <Card16
                    pexelsAndreaPiacquadio839586={card165Props.pexelsAndreaPiacquadio839586}
                    className={card165Props.className}
                  />
                  <Card16
                    pexelsAndreaPiacquadio839586={card166Props.pexelsAndreaPiacquadio839586}
                    className={card166Props.className}
                  />
                  <Card16
                    pexelsAndreaPiacquadio839586={card167Props.pexelsAndreaPiacquadio839586}
                    className={card167Props.className}
                  />
                  <Card16
                    pexelsAndreaPiacquadio839586={card168Props.pexelsAndreaPiacquadio839586}
                    className={card168Props.className}
                  />
                  <Card16
                    pexelsAndreaPiacquadio839586={card169Props.pexelsAndreaPiacquadio839586}
                    className={card169Props.className}
                  />
                </div>
              </div>
            </div>
            <Group195 />
          </div>
        </div>
        <div className="overlap-group21">
          <div className="x8-1">
            <div className="text-30 roboto-medium-blueberry-40px">{text30}</div>
            <div className="text-2 roboto-normal-storm-dust-24px">{text31}</div>
            <div className="overlap-group15" style={{ backgroundImage: `url(${overlapGroup15})` }}>
              <div className="pexels-matheus-ertelli-3856027"></div>
              <Lap2 playProps={lap2Props.playProps} />
            </div>
          </div>
          <div className="group-221">
            <img className="group-6" src={group6} />
            <img className="group-83" src={group83} />
          </div>
        </div>
        <div className="x8-2">
          <div className="text-14 roboto-medium-blueberry-40px">{text14}</div>
          <div className="text-2 roboto-normal-storm-dust-24px">{text15}</div>
          <div className="card1">
            <Group191 />
            <Group191 className={group191Props.className} />
            <Group191 className={group1912Props.className} />
            <Group191 className={group1913Props.className} />
          </div>
        </div>
        <div className="x6-2" style={{ backgroundImage: `url(${x63})` }}>
          <div className="text-11 roboto-medium-blueberry-40px">{text11}</div>
          <div className="text-12 roboto-normal-storm-dust-24px">{text12}</div>
          <div className="flex-row-5">
            <img className="pexels" src={pexelsMatheusBertelli38560272} />
            <img className="pexels-1" src={pexelsHelenaLopes10155683} />
          </div>
          <div className="flex-row">
            <img className="pexels" src={pexelsFauxels31844182} />
            <img className="pexels-1" src={pexelsAlexanderSuhorucov64575623} />
          </div>
          <div className="flex-row">
            <img className="pexels" src={pexelsAlexanderSuhorucov64575624} />
            <img className="pexels-1" src={pexelsHelenaLopes10155684} />
          </div>
          <div className="text-13">{text13}</div>
        </div>
        <div className="x8-3">
          <div className="text-16 roboto-medium-blueberry-40px">{text16}</div>
          <div className="text-2 roboto-normal-storm-dust-24px">{text17}</div>
          <div className="card1-1">
            <div className="group-191">
              <img className="pexels-andrea-p-acquadio-733872" src={pexelsAndreaPiacquadio733872} />
              <div className="name-1 roboto-normal-storm-dust-22px">
                <span className="roboto-normal-azure-radiance-22px">{spanText5}</span>
                <span className="roboto-normal-storm-dust-24px">{spanText6}</span>
                <span className="span2">{spanText7}</span>
                <span className="span3">{spanText8}</span>
              </div>
            </div>
          </div>
          <Group195 className={group195Props.className} />
        </div>
        <div className="overlap-group19">
          <div className="x8-4">
            <div className="our-investors roboto-medium-blueberry-40px">{ourInvestors}</div>
            <div className="text-2 roboto-normal-storm-dust-24px">{text18}</div>
            <ClientLogo22 />
            <ClientLogo22 className={clientLogo22Props.className} />
          </div>
          <div className="overlap-group17">
            <div className="overlap-group-23">
              <img className="bg" src={bg} />
              <img className="background" src={background} />
            </div>
            <div className="creative">
              <div className="creative-1 raleway-bold-white-27px">{creative}</div>
              <div className="animation roboto-medium-white-20px">{animation}</div>
              <div className="drawing roboto-medium-white-20px">{drawing}</div>
              <Link to="/blog">
                <div className="link roboto-medium-white-20px">{graphicDesign}</div>
              </Link>
              <div className="illustration roboto-medium-white-20px">{illustration}</div>
              <div className="photography roboto-medium-white-20px">{photography}</div>
            </div>
            <div className="business">
              <div className="business-1 raleway-bold-white-27px">{business}</div>
              <div className="entrepreneurship roboto-medium-white-20px">{entrepreneurship}</div>
              <div className="freelance-entrepre roboto-medium-white-20px">{freelanceEntrepre}</div>
              <Link to="/shg-library">
                <div className="link roboto-medium-white-20px">{leadership}</div>
              </Link>
              <Link to="/interaction-video">
                <div className="link-1 roboto-medium-white-20px">{marketing}</div>
              </Link>
              <Link to="/game-based-learning">
                <div className="link roboto-medium-white-20px">{productivity}</div>
              </Link>
              <Link to="/virtual-reality">
                <div className="link roboto-medium-white-20px">{more}</div>
              </Link>
            </div>
            <div className="technology">
              <div className="technology-1 raleway-bold-white-27px">{technology}</div>
              <div className="data-science roboto-medium-white-20px">{dataScience}</div>
              <div className="game-design roboto-medium-white-20px">{gameDesign}</div>
              <div className="mobile-development roboto-medium-white-20px">{mobileDevelopment}</div>
              <div className="link-1 roboto-medium-white-20px">{productManagement}</div>
              <div className="link roboto-medium-white-20px">{webDevelopment}</div>
              <div className="more roboto-medium-white-20px">{more2}</div>
              <Link to="/essa">
                <div className="link roboto-medium-white-20px">{productManagement2}</div>
              </Link>
              <Link to="/international">
                <div className="link roboto-medium-white-20px">{webDevelopment2}</div>
              </Link>
              <Link to="/higher-education">
                <div className="link roboto-medium-white-20px">{more3}</div>
              </Link>
            </div>
            <Technology2
              lifestyle={technology2Props.lifestyle}
              crafts={technology2Props.crafts}
              culinary={technology2Props.culinary}
              gaming={technology2Props.gaming}
              healthWellness={technology2Props.healthWellness}
              languages={technology2Props.languages}
            />
            <Group1142 leftProps={group1142Props.leftProps} />
            <img className="path-90" src={path90} />
            <Group116
              followUs={group116Props.followUs}
              facebook1={group116Props.facebook1}
              twitter1={group116Props.twitter1}
              shape={group116Props.shape}
              shgLogo1W={group116Props.shgLogo1W}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default WhoWeAre;
