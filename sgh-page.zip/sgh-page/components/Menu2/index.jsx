import React from "react";
import ButtonSmallPrimary from "../ButtonSmallPrimary";
import "./Menu2.sass";

function Menu2(props) {
  const { x3, buttonSmallPrimaryProps } = props;

  return (
    <div className="menu-1">
      <img
        className="shg-logo1-w"
        src="https://anima-uploads.s3.amazonaws.com/projects/61346f5f10eb46a59c487961/releases/613940f00fa209db6bc1a9c3/img/shg-logo1-w-10@1x.png"
      />
      <ButtonSmallPrimary>{buttonSmallPrimaryProps.children}</ButtonSmallPrimary>
      <img className="x3-1" src={x3} />
    </div>
  );
}

export default Menu2;
