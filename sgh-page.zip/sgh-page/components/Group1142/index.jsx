import React from "react";
import Left from "../Left";
import "./Group1142.sass";

function Group1142(props) {
  const { leftProps } = props;

  return (
    <div className="group-114">
      <img
        className="line"
        src="https://anima-uploads.s3.amazonaws.com/projects/61346f5f10eb46a59c487961/releases/613940f00fa209db6bc1a9c3/img/line-16@1x.png"
      />
      <Left {...leftProps} />
    </div>
  );
}

export default Group1142;
