import React from "react";
import Play from "../Play";
import "./Lap2.sass";

function Lap2(props) {
  const { playProps } = props;

  return (
    <div className="lap">
      <Play src={playProps.src} />
    </div>
  );
}

export default Lap2;
