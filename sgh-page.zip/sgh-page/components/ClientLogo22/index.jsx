import React from "react";
import Logo22 from "../Logo22";
import Logo32 from "../Logo32";
import Logo43 from "../Logo43";
import "./ClientLogo22.sass";

function ClientLogo22(props) {
  const { className } = props;

  return (
    <div className={`client-logo ${className || ""}`}>
      <div className="logo-1">
        <img
          className="combined-shape"
          src="https://anima-uploads.s3.amazonaws.com/projects/61346f5f10eb46a59c487961/releases/613940f00fa209db6bc1a9c3/img/combined-shape-50@1x.png"
        />
      </div>
      <Logo22 />
      <Logo32 />
      <Logo43 />
    </div>
  );
}

export default ClientLogo22;
