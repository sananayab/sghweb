import React from "react";
import "./Logo32.sass";

function Logo32() {
  return (
    <div className="logo-3">
      <img
        className="combined-shape-2"
        src="https://anima-uploads.s3.amazonaws.com/projects/61346f5f10eb46a59c487961/releases/613940f00fa209db6bc1a9c3/img/combined-shape-54@1x.png"
      />
    </div>
  );
}

export default Logo32;
