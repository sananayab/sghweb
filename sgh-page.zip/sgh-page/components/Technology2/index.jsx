import React from "react";
import "./Technology2.sass";

function Technology2(props) {
  const { lifestyle, crafts, culinary, gaming, healthWellness, languages } = props;

  return (
    <div className="technology-2">
      <div className="lifestyle raleway-bold-white-27px">{lifestyle}</div>
      <div className="crafts roboto-medium-white-20px">{crafts}</div>
      <div className="technology-item roboto-medium-white-20px">{culinary}</div>
      <div className="technology-item-1 roboto-medium-white-20px">{gaming}</div>
      <div className="technology-item roboto-medium-white-20px">{healthWellness}</div>
      <div className="technology-item-1 roboto-medium-white-20px">{languages}</div>
    </div>
  );
}

export default Technology2;
