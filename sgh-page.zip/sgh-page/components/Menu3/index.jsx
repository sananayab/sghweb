import React from "react";
import "./Menu3.sass";

function Menu3() {
  return (
    <div className="menu">
      <img
        className="logo"
        src="https://anima-uploads.s3.amazonaws.com/projects/61346f5f10eb46a59c487961/releases/613940f00fa209db6bc1a9c3/img/logo-10@1x.png"
      />
      <div className="place lato-bold-cararra-32px">University</div>
    </div>
  );
}

export default Menu3;
