import React from "react";
import Menu3 from "../Menu3";
import Request from "../Request";
import "./HEADER5.sass";

function HEADER5(props) {
  const { x3, signupBtn2Props, signupBtn22Props } = props;

  return (
    <div className="group-87">
      <Menu3 />
      <Request>{signupBtn2Props.children}</Request>
      <Request className={signupBtn22Props.className}>{signupBtn22Props.children}</Request>
      <img className="x3" src={x3} />
    </div>
  );
}

export default HEADER5;
