import React from "react";
import "./Logo43.sass";

function Logo43() {
  return (
    <div className="logo-4">
      <img
        className="combined-shape-3"
        src="https://anima-uploads.s3.amazonaws.com/projects/61346f5f10eb46a59c487961/releases/613940f00fa209db6bc1a9c3/img/combined-shape-56@1x.png"
      />
    </div>
  );
}

export default Logo43;
