import React from "react";
import Group1952 from "../Group1952";
import "./Group195.sass";

function Group195(props) {
  const { className } = props;

  return (
    <div className={`group-195 ${className || ""}`}>
      <Group1952 />
    </div>
  );
}

export default Group195;
