import React from "react";
import "./Group92.sass";

function Group92() {
  return (
    <div className="group-92">
      <div className="overlap-group-24">
        <img
          className="line-8"
          src="https://anima-uploads.s3.amazonaws.com/projects/61346f5f10eb46a59c487961/releases/613940f00fa209db6bc1a9c3/img/line-8-10@1x.png"
        />
        <img
          className="line-9"
          src="https://anima-uploads.s3.amazonaws.com/projects/61346f5f10eb46a59c487961/releases/613940f00fa209db6bc1a9c3/img/line-9-10@1x.png"
        />
      </div>
    </div>
  );
}

export default Group92;
