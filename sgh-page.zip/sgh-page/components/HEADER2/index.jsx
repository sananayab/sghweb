import React from "react";
import HEADER5 from "../HEADER5";
import "./HEADER2.sass";

function HEADER2(props) {
  const { hEADER5Props } = props;

  return (
    <div className="header">
      <HEADER5
        x3={hEADER5Props.x3}
        signupBtn2Props={hEADER5Props.signupBtn2Props}
        signupBtn22Props={hEADER5Props.signupBtn22Props}
      />
    </div>
  );
}

export default HEADER2;
