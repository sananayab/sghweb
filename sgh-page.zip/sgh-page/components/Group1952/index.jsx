import React from "react";
import "./Group1952.sass";

function Group1952() {
  return (
    <div className="group-183-1">
      <div className="ellipse-70"></div>
      <div className="ellipse"></div>
      <div className="ellipse-44"></div>
      <div className="ellipse"></div>
      <div className="ellipse"></div>
      <div className="ellipse"></div>
      <div className="ellipse"></div>
    </div>
  );
}

export default Group1952;
