import React from "react";
import "./Request.sass";

function Request(props) {
  const { children, className } = props;

  return (
    <div className={`request border-1px-white ${className || ""}`}>
      <div className="request-a-qoute roboto-normal-cararra-18px">{children}</div>
    </div>
  );
}

export default Request;
