
## Instructions
```
cd package_code
npm install
npm start
```
Open [http://localhost:1234](http://localhost:1234).